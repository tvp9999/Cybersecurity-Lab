<?php
include 'config.php';
$page_title='Product';
include 'partials/header.php';

$id = $_GET['id']; // ⚠ SQLi
$item = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM items WHERE id=$id"));
if (!$item) { echo "<div class='alert alert-danger'>Item not found</div>"; include 'partials/footer.php'; exit; }

if (isset($_POST['review'])) {
  $author = isset($_SESSION['user']) ? $_SESSION['user'] : 'guest';
  $content = $_POST['content']; // ⚠ Stored XSS
  mysqli_query($conn, "INSERT INTO reviews (item_id, author, content) VALUES ($id, '$author', '$content')");
  echo "<div class='alert alert-success'>Review added</div>";
}
$rev = mysqli_query($conn, "SELECT * FROM reviews WHERE item_id=$id ORDER BY id DESC");
?>
<div class="row g-4">
  <div class="col-md-5">
    <?php if ($item['image']): ?>
      <img class="img-fluid rounded" src="<?= $item['image'] ?>">
    <?php else: ?>
      <div class="ratio ratio-1x1 bg-secondary-subtle d-flex align-items-center justify-content-center">No Image</div>
    <?php endif; ?>
  </div>
  <div class="col-md-7">
    <h2><?= $item['name'] ?></h2>
    <p class="lead">$<?= $item['price'] ?></p>
    <p><?= $item['description'] ?></p>
    <div class="mb-2">Stock: <?= $item['quantity'] ?></div>
    <a class="btn btn-success" href="add_to_cart.php?id=<?= $item['id'] ?>">Add to Cart</a>
  </div>
</div>

<hr>
<h4>Reviews</h4>
<form method="post" class="mb-3">
  <textarea name="content" class="form-control" rows="3" placeholder="Write a review (HTML allowed)"></textarea>
  <button class="btn btn-primary mt-2" name="review">Post Review</button>
</form>
<?php while ($r = mysqli_fetch_assoc($rev)): ?>
  <div class="border rounded p-2 mb-2">
    <div class="small text-muted"><?= $r['author'] ?> @ <?= $r['created_at'] ?></div>
    <div><?= $r['content'] ?></div>
  </div>
<?php endwhile; ?>
<?php include 'partials/footer.php'; ?>
