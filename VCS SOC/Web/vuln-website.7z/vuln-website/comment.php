<?php include 'config.php'; $page_title='Reviews Wall'; include 'partials/header.php'; ?>
<h1>Public Reviews Wall</h1>
<form method="post" class="mb-3">
  <textarea name="content" class="form-control" placeholder="Write anything (HTML allowed)"></textarea>
  <button class="btn btn-primary mt-2" name="post">Post</button>
</form>
<?php
if (isset($_POST['post'])) {
  $c = $_POST['content']; // ⚠ stored XSS
  mysqli_query($conn, "INSERT INTO reviews (item_id, author, content) VALUES (0, 'wall', '$c')");
  echo "<div class='alert alert-success'>Posted</div>";
}
$res = mysqli_query($conn, "SELECT * FROM reviews WHERE item_id=0 ORDER BY id DESC");
while ($r = mysqli_fetch_assoc($res)) {
  echo "<div class='border rounded p-2 mb-2'>{$r['content']}</div>";
}
include 'partials/footer.php'; ?>
