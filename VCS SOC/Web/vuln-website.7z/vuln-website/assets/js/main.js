console.log('Vulnerable e-commerce loaded');
