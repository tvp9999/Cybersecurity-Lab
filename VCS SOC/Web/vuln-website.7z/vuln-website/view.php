<?php 
$page_title='Pages'; 
include 'partials/header.php'; 

// Ưu tiên: nếu nhập đường dẫn custom thì lấy, nếu không thì lấy từ dropdown
if (isset($_GET['page_custom']) && $_GET['page_custom'] !== '') {
    $chosen = $_GET['page_custom'];
} elseif (isset($_GET['page_select']) && $_GET['page_select'] !== '') {
    $chosen = $_GET['page_select'];
} else {
    $chosen = 'pages/home.php'; // fallback mặc định
}

if (isset($_GET['preview'])) {
    // ⚠️ LFI/RFI sink (enable allow_url_include=On in php.ini for RFI)
    include($chosen);
    include 'partials/footer.php'; 
    exit;
}
?>

<h1>Pages</h1>
<form class="row gy-2 gx-2 align-items-end" method="get">
  <div class="col-md-4">
    <label class="form-label">Choose a page</label>
    <select name="page_select" class="form-select">
      <option value="pages/home.php"  <?= $chosen==='pages/home.php'?'selected':'' ?>>Home</option>
      <option value="pages/about.php" <?= $chosen==='pages/about.php'?'selected':'' ?>>About</option>
      <option value="pages/contact.php" <?= $chosen==='pages/contact.php'?'selected':'' ?>>Contact</option>
      <option value="pages/faq.php" <?= $chosen==='pages/faq.php'?'selected':'' ?>>FAQ</option>
    </select>
  </div>
  <div class="col-md-5">
    <label class="form-label">Or custom path / URL</label>
    <input class="form-control" name="page_custom" value="<?= htmlspecialchars($chosen) ?>">
  </div>
  <div class="col-md-3">
    <input type="hidden" name="preview" value="1">
    <button class="btn btn-primary w-100">Preview</button>
  </div>
</form>

<div class="alert alert-warning mt-3">
  This preview loads the file directly on the server (demo purpose).
</div>
<div class="small text-muted">Current: <code><?= htmlspecialchars($chosen) ?></code></div>

<?php include 'partials/footer.php'; ?>
