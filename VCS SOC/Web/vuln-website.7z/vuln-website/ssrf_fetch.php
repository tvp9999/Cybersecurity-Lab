<?php
// ssrf_fetch.php — intentionally unsafe SSRF demo
include 'config.php';
$page_title = "SSRF Fetch Demo";
include 'partials/header.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $url = $_POST['url']; // ⚠ no validation
  echo "<h5>Fetching: " . htmlspecialchars($url) . "</h5>";
  $data = @file_get_contents($url); // SSRF sink
  if ($data === false) {
    echo "<div class='alert alert-danger'>Fetch failed.</div>";
  } else {
    echo "<div class='alert alert-success'>Success! Showing first 300 bytes:</div>";
    echo "<pre>" . htmlspecialchars(substr($data,0,300)) . "</pre>";
  }
}
?>

<form method="post" class="card p-3" style="max-width:640px">
  <label class="form-label">Remote URL</label>
  <input class="form-control mb-2" name="url" placeholder="http://example.com/">
  <button class="btn btn-primary">Fetch</button>
</form>

<?php include 'partials/footer.php'; ?>
