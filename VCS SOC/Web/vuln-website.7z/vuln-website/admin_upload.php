<?php
// Intentionally unsafe: public web path, no validation
if (isset($_FILES['file'])) {
  $target = "assets/uploads/" . basename($_FILES['file']['name']);
  if (move_uploaded_file($_FILES['file']['tmp_name'], $target)) {
    echo "Uploaded: <a href='$target'>$target</a> | <a href='admin.php'>Back</a>";
  } else {
    echo "Upload failed. <a href='admin.php'>Back</a>";
  }
} else {
  header("Location: admin.php");
}
