<?php
include 'config.php';
session_start();
if (!isset($_SESSION['user'])) { die("Login required. <a href='login.php'>Login</a>"); }

$id = $_GET['id']; // ⚠ SQLi
$u  = $_SESSION['user'];
$row = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM cart_items WHERE user='$u' AND item_id=$id"));
if ($row) {
  mysqli_query($conn, "UPDATE cart_items SET qty=qty+1 WHERE id={$row['id']}");
} else {
  mysqli_query($conn, "INSERT INTO cart_items (user, item_id, qty) VALUES ('$u',$id,1)");
}
header("Location: cart.php"); exit;
