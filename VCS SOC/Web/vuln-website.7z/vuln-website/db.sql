CREATE DATABASE IF NOT EXISTS vulnsite;
USE vulnsite;

DROP TABLE IF EXISTS users;
DROP TABLE IF EXISTS items;
DROP TABLE IF EXISTS reviews;
DROP TABLE IF EXISTS cart_items;
DROP TABLE IF EXISTS orders;
DROP TABLE IF EXISTS order_items;

CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) NOT NULL,
  password VARCHAR(255) NOT NULL,  -- ⚠ plaintext on purpose
  role VARCHAR(10) DEFAULT 'user',
  balance DECIMAL(10,2) DEFAULT 300.00
);

INSERT INTO users (username, password, role, balance) VALUES
('admin', 'admin123', 'admin', 9999.99),
('test',  '123456',   'user',  200.00);

CREATE TABLE items (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100),
  description TEXT,
  price DECIMAL(10,2),
  quantity INT,
  image VARCHAR(255),
  category VARCHAR(50)
);

INSERT INTO items (name, description, price, quantity, image, category) VALUES
('Laptop', 'VulnerableStore Laptop 15"', 500.00, 10, NULL, 'Electronics'),
('Phone',  'InsecurePhone Model X',      300.00, 15, NULL, 'Electronics'),
('Hoodie', 'Comfy hoodie (no checks)',     49.99, 50, NULL, 'Apparel');

CREATE TABLE reviews (
  id INT AUTO_INCREMENT PRIMARY KEY,
  item_id INT,
  author VARCHAR(50),
  content TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE cart_items (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user VARCHAR(50),
  item_id INT,
  qty INT DEFAULT 1
);

CREATE TABLE orders (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user VARCHAR(50),
  total DECIMAL(10,2),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE order_items (
  id INT AUTO_INCREMENT PRIMARY KEY,
  order_id INT,
  item_id INT,
  qty INT,
  price DECIMAL(10,2)
);
