<?php
include 'config.php';
$page_title='Orders';
include 'partials/header.php';

if (!isset($_SESSION['user'])) { echo "Login required. <a href='login.php'>Login</a>"; include 'partials/footer.php'; exit; }
$u = $_SESSION['user'];
$orders = mysqli_query($conn, "SELECT * FROM orders WHERE user='$u' ORDER BY id DESC");
?>
<h1>My Orders</h1>
<?php while ($o = mysqli_fetch_assoc($orders)): ?>
  <div class="card mb-3">
    <div class="card-body">
      <div class="d-flex justify-content-between">
        <div><b>Order #<?= $o['id'] ?></b> on <?= $o['created_at'] ?></div>
        <div>Total: $<?= $o['total'] ?></div>
      </div>
      <table class="table table-sm mt-2 mb-0">
        <tr><th>Item</th><th>Qty</th><th>Price</th></tr>
        <?php
          $oi = mysqli_query($conn, "SELECT i.name, oi.qty, oi.price FROM order_items oi JOIN items i ON oi.item_id=i.id WHERE oi.order_id=".$o['id']);
          while ($r = mysqli_fetch_assoc($oi)):
        ?>
          <tr><td><?= $r['name'] ?></td><td><?= $r['qty'] ?></td><td>$<?= $r['price'] ?></td></tr>
        <?php endwhile; ?>
      </table>
    </div>
  </div>
<?php endwhile; ?>
<?php include 'partials/footer.php'; ?>
