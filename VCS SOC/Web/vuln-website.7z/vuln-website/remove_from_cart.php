<?php
include 'config.php';
session_start();
$id = $_GET['id']; // ⚠ SQLi
mysqli_query($conn, "DELETE FROM cart_items WHERE id=$id");
header("Location: cart.php");
