<?php
include 'config.php';
$page_title='Cart';
include 'partials/header.php';

if (!isset($_SESSION['user'])) { echo "Login required. <a href='login.php'>Login</a>"; include 'partials/footer.php'; exit; }
$u = $_SESSION['user'];
$rows = mysqli_query($conn, "SELECT c.id as cid, i.* , c.qty FROM cart_items c JOIN items i ON c.item_id=i.id WHERE c.user='$u'");
$total = 0;
?>
<h1>Your Cart</h1>
<table class="table">
<tr><th>Item</th><th>Price</th><th>Qty</th><th>Subtotal</th><th></th></tr>
<?php while ($r = mysqli_fetch_assoc($rows)): $sub = $r['price']*$r['qty']; $total += $sub; ?>
<tr>
  <td><?= $r['name'] ?></td>
  <td>$<?= $r['price'] ?></td>
  <td><?= $r['qty'] ?></td>
  <td>$<?= number_format($sub,2) ?></td>
  <td><a class="btn btn-sm btn-outline-danger" href="remove_from_cart.php?id=<?= $r['cid'] ?>">Remove</a></td>
</tr>
<?php endwhile; ?>
</table>
<div class="d-flex justify-content-between align-items-center">
  <h4>Total: $<?= number_format($total,2) ?></h4>
  <form method="post" action="checkout.php" class="m-0">
    <button class="btn btn-primary">Checkout</button>
  </form>
</div>
<?php include 'partials/footer.php'; ?>
