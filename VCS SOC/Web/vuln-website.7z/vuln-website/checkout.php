<?php
include 'config.php';
session_start();
if (!isset($_SESSION['user'])) { die("Login required. <a href='login.php'>Login</a>"); }
$u = $_SESSION['user'];

// Accept POST only (still no CSRF token → vulnerable by design)
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
  http_response_code(405);
  die("Invalid request");
}

$rows = mysqli_query($conn, "SELECT c.id as cid, i.* , c.qty FROM cart_items c JOIN items i ON c.item_id=i.id WHERE c.user='$u'");
$items = [];
$total = 0;
while ($r = mysqli_fetch_assoc($rows)) { $items[] = $r; $total += $r['price']*$r['qty']; }

$bal = mysqli_fetch_assoc(mysqli_query($conn, "SELECT balance FROM users WHERE username='$u'"))['balance'];
if ($bal < $total) die("Not enough balance. <a href='cart.php'>Back</a>");

mysqli_query($conn, "INSERT INTO orders (user, total) VALUES ('$u',$total)");
$order_id = mysqli_insert_id($conn);

foreach ($items as $it) {
  mysqli_query($conn, "INSERT INTO order_items (order_id,item_id,qty,price) VALUES ($order_id, {$it['id']}, {$it['qty']}, {$it['price']})");
  mysqli_query($conn, "UPDATE items SET quantity=quantity-{$it['qty']} WHERE id={$it['id']}");
}
mysqli_query($conn, "UPDATE users SET balance=balance-$total WHERE username='$u'");
mysqli_query($conn, "DELETE FROM cart_items WHERE user='$u'");

echo "Order #$order_id placed! <a href='orders.php'>View orders</a>";
