<?php
// Intentionally weak DB config for lab use only
$host = "localhost";
$user = "root";
$pass = "";       // set your local MySQL root password if any
$db   = "vulnsite";

$conn = mysqli_connect($host, $user, $pass, $db);
if (!$conn) { die("DB connection failed: " . mysqli_connect_error()); }
?>
