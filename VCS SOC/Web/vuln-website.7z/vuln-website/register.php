<?php
include 'config.php'; session_start();
$page_title='Register'; include 'partials/header.php';

if (isset($_POST['register'])) {
  $u = $_POST['username']; $p = $_POST['password'];
  mysqli_query($conn, "INSERT INTO users (username,password) VALUES ('$u','$p')"); // ⚠ plaintext
  echo "<div class='alert alert-success'>Registered</div>";
}
?>
<h1>Register</h1>
<form method="post" class="card p-3">
  <input class="form-control mb-2" name="username" placeholder="Username">
  <input class="form-control mb-2" name="password" placeholder="Password">
  <button class="btn btn-primary" name="register">Register</button>
</form>
<?php include 'partials/footer.php'; ?>
