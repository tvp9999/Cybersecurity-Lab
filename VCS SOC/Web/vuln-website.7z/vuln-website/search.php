<?php include 'config.php'; $page_title='Search'; include 'partials/header.php'; ?>
<h1>Search</h1>
<form method="get" class="mb-3">
  <input class="form-control" name="q" placeholder="Search products">
</form>
<?php
if (isset($_GET['q'])) {
  $q = $_GET['q'];
  echo "<p>Results for: $q</p>"; // ⚠ reflected XSS
  $res = mysqli_query($conn, "SELECT * FROM items WHERE name LIKE '%$q%' OR description LIKE '%$q%'"); // ⚠ SQLi
  echo "<ul>";
  while ($r = mysqli_fetch_assoc($res)) {
    echo "<li><a href='product.php?id={$r['id']}'>{$r['name']}</a></li>";
  }
  echo "</ul>";
}
include 'partials/footer.php'; ?>
