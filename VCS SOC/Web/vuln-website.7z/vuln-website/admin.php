<?php
include 'config.php'; session_start();
$page_title='Admin';
include 'partials/header.php';

if (!isset($_SESSION['user']) || $_SESSION['user']!='admin') { die("Access denied. <a href='login.php'>Login</a>"); }

// ADD new item
if (isset($_POST['add'])) {
  $n=$_POST['name']; $d=$_POST['description']; $p=$_POST['price']; $q=$_POST['quantity']; $c=$_POST['category'];
  mysqli_query($conn, "INSERT INTO items (name,description,price,quantity,category) VALUES ('$n','$d','$p','$q','$c')");
}

// DELETE item
if (isset($_POST['delete'])) {
  $id=$_POST['delete'];
  mysqli_query($conn, "DELETE FROM items WHERE id=$id"); // ⚠️ SQLi by design
}

// SET image path
if (isset($_POST['setimg'])) {
  $id=$_POST['id']; $img=$_POST['image'];
  mysqli_query($conn, "UPDATE items SET image='$img' WHERE id=$id");
}

// EDIT: fetch item to prefill
$editItem = null;
if (isset($_GET['edit'])) {
  $eid = $_GET['edit']; // ⚠️
  $editItem = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM items WHERE id=$eid"));
}

// UPDATE existing item
if (isset($_POST['update'])) {
  $id=$_POST['id']; $n=$_POST['name']; $d=$_POST['description']; $p=$_POST['price']; $q=$_POST['quantity']; $c=$_POST['category'];
  mysqli_query($conn, "UPDATE items SET name='$n', description='$d', price='$p', quantity='$q', category='$c' WHERE id=$id");
  // refresh the edit view
  $editItem = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM items WHERE id=$id"));
  echo "<div class='alert alert-success'>Item #$id updated</div>";
}

$items = mysqli_query($conn, "SELECT * FROM items ORDER BY id DESC");
?>
<h1>Admin</h1>

<div class="row g-3">
  <div class="col-lg-6">
    <div class="card p-3">
      <h5><?= $editItem ? "Edit Item #".$editItem['id'] : "Add Item" ?></h5>
      <form method="post">
        <?php if ($editItem): ?>
          <input type="hidden" name="id" value="<?= $editItem['id'] ?>">
        <?php endif; ?>
        <input class="form-control mb-2" name="name" placeholder="Name" value="<?= $editItem ? $editItem['name'] : '' ?>">
        <input class="form-control mb-2" name="description" placeholder="Description (HTML allowed)" value="<?= $editItem ? htmlspecialchars($editItem['description']) : '' ?>">
        <input class="form-control mb-2" name="price" placeholder="Price" value="<?= $editItem ? $editItem['price'] : '' ?>">
        <input class="form-control mb-2" name="quantity" placeholder="Quantity" value="<?= $editItem ? $editItem['quantity'] : '' ?>">
        <input class="form-control mb-2" name="category" placeholder="Category" value="<?= $editItem ? $editItem['category'] : '' ?>">
        <?php if ($editItem): ?>
          <button class="btn btn-warning" name="update">Update</button>
          <a class="btn btn-outline-secondary" href="admin.php">Cancel</a>
        <?php else: ?>
          <button class="btn btn-primary" name="add">Add</button>
        <?php endif; ?>
      </form>
    </div>

    <div class="card p-3 mt-3">
      <h5>Upload Product Image (public)</h5>
      <form method="post" action="admin_upload.php" enctype="multipart/form-data">
        <input type="file" name="file" class="form-control mb-2">
        <button class="btn btn-secondary">Upload</button>
      </form>
      <div class="small text-muted mt-2">Uploaded files appear under <code>assets/uploads/</code>.</div>
    </div>
  </div>

  <div class="col-lg-6">
    <div class="card p-3">
      <h5>Items</h5>
      <table class="table table-sm align-middle">
        <tr><th>ID</th><th>Name</th><th>Price</th><th>Qty</th><th>Image</th><th>Actions</th></tr>
        <?php while ($r = mysqli_fetch_assoc($items)): ?>
        <tr>
          <td><?= $r['id'] ?></td>
          <td><?= $r['name'] ?></td>
          <td>$<?= $r['price'] ?></td>
          <td><?= $r['quantity'] ?></td>
          <td style="max-width:220px">
            <form method="post" class="d-flex gap-1">
              <input type="hidden" name="id" value="<?= $r['id'] ?>">
              <input class="form-control form-control-sm" name="image" placeholder="assets/uploads/xyz.jpg" value="<?= $r['image'] ?>">
              <button class="btn btn-sm btn-outline-primary" name="setimg">Set</button>
            </form>
          </td>
          <td>
            <a class="btn btn-sm btn-warning" href="?edit=<?= $r['id'] ?>">Edit</a>
            <form method="post" action="admin.php" style="display:inline">
              <input type="hidden" name="delete" value="<?= $r['id'] ?>">
              <button class="btn btn-sm btn-danger">Delete</button>
            </form>
          </td>
        </tr>
        <?php endwhile; ?>
      </table>
    </div>
  </div>
</div>
<?php include 'partials/footer.php'; ?>
