<?php
include 'config.php';
session_start();
$page_title='Login';
include 'partials/header.php';

if (isset($_POST['login'])) {
  $u = $_POST['username']; $p = $_POST['password'];
  $sql = "SELECT * FROM users WHERE username='$u' AND password='$p'"; // ⚠️ SQLi & plaintext by design
  $res = mysqli_query($conn, $sql);
  if ($res && mysqli_num_rows($res)>0) {
    $_SESSION['user']=$u;

    // Get role to decide redirect
    $row = mysqli_fetch_assoc($res);
    if ($row && $row['role']==='admin') {
      header("Location: admin.php"); exit;
    } else {
      $_SESSION['flash'] = "Hello, $u";
      header("Location: index.php"); exit;
    }
  } else {
    echo "<div class='alert alert-danger'>Invalid username or password</div>";
  }
}
?>
<h1>Login</h1>
<form method="post" class="card p-3">
  <input class="form-control mb-2" name="username" placeholder="Username">
  <input class="form-control mb-2" name="password" placeholder="Password">
  <button class="btn btn-primary" name="login">Login</button>
</form>
<?php include 'partials/footer.php'; ?>
