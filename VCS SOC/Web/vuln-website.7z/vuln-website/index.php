<?php
include 'config.php';
$page_title='Shop';
include 'partials/header.php';

if (isset($_SESSION['flash'])) {
  echo "<div class='alert alert-success'>".$_SESSION['flash']."</div>";
  unset($_SESSION['flash']);
}

$cat = isset($_GET['cat']) ? $_GET['cat'] : '';
$q = "SELECT * FROM items";
if ($cat) $q .= " WHERE category='$cat'"; // ⚠️ SQLi by design
$res = mysqli_query($conn, $q);
?>
<h1 class="mb-3">Products</h1>
<div class="mb-3">
  <a class="btn btn-outline-secondary btn-sm" href="index.php">All</a>
  <a class="btn btn-outline-secondary btn-sm" href="index.php?cat=Electronics">Electronics</a>
  <a class="btn btn-outline-secondary btn-sm" href="index.php?cat=Apparel">Apparel</a>
</div>

<div class="row g-3">
<?php while ($r = mysqli_fetch_assoc($res)): ?>
  <div class="col-sm-6 col-md-4 col-lg-3">
    <div class="card h-100">
      <?php if ($r['image']): ?>
        <img class="card-img-top" src="<?= $r['image'] ?>" alt="image" style="height:180px;object-fit:cover">
      <?php else: ?>
        <div class="card-img-top d-flex align-items-center justify-content-center bg-secondary-subtle" style="height:180px">No Image</div>
      <?php endif; ?>
      <div class="card-body d-flex flex-column">
        <h5 class="card-title"><a href="product.php?id=<?= $r['id'] ?>"><?= $r['name'] ?></a></h5>
        <p class="card-text small flex-grow-1"><?= $r['description'] ?></p>
        <div class="d-flex justify-content-between align-items-center">
          <span class="fw-bold">$<?= $r['price'] ?></span>
          <a class="btn btn-sm btn-success" href="add_to_cart.php?id=<?= $r['id'] ?>">Add to Cart</a>
        </div>
        <div class="small mt-2 text-muted">Stock: <?= $r['quantity'] ?></div>
      </div>
    </div>
  </div>
<?php endwhile; ?>
</div>
<?php include 'partials/footer.php'; ?>
