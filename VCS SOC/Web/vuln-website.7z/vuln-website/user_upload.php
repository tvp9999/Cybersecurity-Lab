<?php
include 'config.php'; session_start(); $page_title='My Profile'; include 'partials/header.php';
if (!isset($_SESSION['user'])) { echo "<div class='alert alert-info'>Login required. <a href='login.php'>Login</a></div>"; include 'partials/footer.php'; exit; }
$msg='';
if (!empty($_FILES['photo']['name'])) {
  $target = 'assets/uploads/' . basename($_FILES['photo']['name']);
  if (move_uploaded_file($_FILES['photo']['tmp_name'], $target)) { $msg = "Uploaded! <a href='$target' target='_blank'>$target</a>"; }
  else { $msg = "Upload failed."; }
}
?>
<h1>My Profile</h1>
<form method="post" enctype="multipart/form-data" class="card p-3">
  <label class="form-label">Upload profile photo</label>
  <input type="file" name="photo" class="form-control mb-2">
  <button class="btn btn-primary">Upload</button>
</form>
<?php if ($msg): ?><div class="alert alert-secondary mt-3"><?= $msg ?></div><?php endif; ?>
<p class="text-muted small">Note: secure apps would validate file type/size and store outside web root.</p>
<?php include 'partials/footer.php'; ?>
