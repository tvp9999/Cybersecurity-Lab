<?php
if (isset($_FILES['file'])) {
  $target = "assets/uploads/" . basename($_FILES['file']['name']);
  if (move_uploaded_file($_FILES['file']['tmp_name'], $target)) echo "Uploaded: <a href='$target'>$target</a>";
  else echo "Upload failed";
}
?>
<form method="post" enctype="multipart/form-data">
  <input type="file" name="file">
  <button>Upload</button>
</form>
