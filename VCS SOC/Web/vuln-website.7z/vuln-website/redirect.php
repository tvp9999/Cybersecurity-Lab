<?php
$url = $_GET['url'] ?? "index.php";
// ⚠️ Open redirect, attacker can abuse it
header("Location: $url");
exit;
?>
